package com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.view.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.R
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.databinding.FragmentFirstBinding
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.view.dialogs.MyDialogFragment
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.viewmodel.AppIncidenciasViewModel

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment(), MyDialogFragment.OkOrCancelDialogable {

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    // Adaptació a MVVM: Eliminem la línia:
    //private var incidenciaToRemove: Inciencia?=null
    // ja que aquest incidencia a eliminar el gestionarem des
    // del ViewModel a través de LiveData


    // Adaptació a MVVM: Definim una instància del ViewModel com a lateinit
    private lateinit var viewModel: AppIncidenciasViewModel

    // Adaptació a MVVM: Eliminem els mètodes onCreate i
    // onSaveInstanceState, ja que ara no són necessaris

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Injectem la interfície a través del View Binding
        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        // I la retornem
        return binding.root


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // En primer lloc, anem a instanciar el ViewModel, mitjançant la classe
        // ViewModelProvider. Aci es on la vista "s'enganxa" al ViewModel.
        // Compte que com a owner hem d'afegir requireActivity() en lloc de
        // this, per a que l'àmbit del ViewModel siga ara el de l'activitat,
        // de manera que es puga compartir entre els fragments.
        viewModel = ViewModelProvider(requireActivity()).get(AppIncidenciasViewModel::class.java)

        // Preparem el RecyclerView

        // 1. Associem el LayoutManager
        binding.IncidenciesRecyclerView.layoutManager = LinearLayoutManager(requireActivity())

        // 2.Creem un observador y el subscribim al LiveData adapter
        // Definido del ViewModel. Asi, Que cuando lo produzcamos canvios al ViewModel
        // es reflejaran en el adapter del RecyclerView
        viewModel.adaptador.observe(viewLifecycleOwner) {

            binding.IncidenciesRecyclerView.adapter = it
        }

        // 3. Creem un altre observer, i el subscrivim als canvis que
        //    es produisquen a l'objecte incidenciaClicked del ViewModel.
        //    En aquest cas, per crear l'observer, es rep el incidencia
        //    sobre el que hem fet click.
        viewModel.incidenciaClicked.observe(viewLifecycleOwner) { incidencia->
            incidencia?.let{
                viewModel.incidenciaClicked.value = null

                //Y lanzamos la nevegacion ninguna al fragmento de edicion
                //val bundle = bundle of("incidencia" to incidencia)
                viewModel.setIncidenciaActual(incidencia)
                findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
            }

        }

        // 4. Creem un tercer observer i el subscrivim als canvis que es
        //    produisquen a l'objecte incidenciaLongClicked del ViewModel,
        //    a l'igual que en el cas anterior.
        viewModel.incidenciaClicked.observe(viewLifecycleOwner){ incidencia->
            incidencia?.let{
                // Ressetegem el valor
                viewModel.incidenciaLongClicked.value = null

                // Llancem l'acció corresponent al click llarg; mostrar
                // el diàleg de confirmació d'eliminació de l'element.
                val myDialog = MyDialogFragment(
                    resources.getString(R.string.askRemoveTitle),
                    resources.getString(R.string.askRemove) + incidencia.assumpte + "?"
                )
                myDialog.show(parentFragmentManager, "MyDialog")
            }
        }
        viewModel.incidenciaList.observe(viewLifecycleOwner){ incidencia->
            incidencia?.let{
                if (viewModel.deletedPos.value ==null){
                    viewModel.adaptador.value?.notifyItemRemoved(viewModel.deletedPos.value!!)
                    viewModel.deletedPos.value = null
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Els mètodes itemClicked i itemLongCLicked s'han eliminat d'aci,
    // ja que ara és el viewModel qui detecta els clicks a través del ViewHolder,
    // ides d'aci es gestionen amb els observers definits més amunt.

    // Com que la vista segueix implementant la interfície
    // MyDialogFragment.OkOrCancelDialogable, cal implementar
    // els mètodes onPositiveClick quan fem click
    // en acceptar al diàleg, i onCancelClick.

    override fun onPositiveClick() {
        // Si es prem a Acceptar en el diàleg eliminem l'item.

        val incidenciaToRemove= viewModel.incidenciaToRemove.value
        viewModel.incidenciaToRemove.value = null

        // Si existe esta incidencia...
        incidenciaToRemove?.also {
            //En vez de eliminar la incidencia directamente, lo pasamos a traves del metodo removeIncidencia
            viewModel.removeIncidencia(it)
        }

    }
    override fun onCancelClick() {
        Toast.makeText(requireActivity().applicationContext,
            R.string.ActionCancelled, Toast.LENGTH_SHORT).show()
    }
}