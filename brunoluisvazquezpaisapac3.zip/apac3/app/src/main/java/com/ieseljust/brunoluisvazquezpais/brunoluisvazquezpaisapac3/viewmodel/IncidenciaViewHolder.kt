package com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.viewmodel

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.R
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.model.db.Incidencia

class IncidenciaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

    val img = itemView.findViewById(R.id.imageView2) as ImageView
    val asumpte = itemView.findViewById(R.id.textView) as TextView
    val descripcio = itemView.findViewById(R.id.textView2) as TextView

    // Enllacem les dades de la incidencia amb la vista
    // i amb els seus gestors d'esdeveniments, com a funcions Lambda
    fun bind(
        incidencia: Incidencia,
        eventListenerClick: (Incidencia) -> Unit,
        eventListenerLongClick: (Incidencia) -> Boolean
    ) {
        asumpte.text = incidencia.assumpte
        descripcio.text = incidencia.descripcio
        img.setImageResource(incidencia.img)

        /* Ara capturem els esdeveniments i invoquem el callback corresponent */

        // Click normal
        itemView.setOnClickListener{
            eventListenerClick(incidencia)
            }

        // Click llarg
        itemView.setOnLongClickListener{
            eventListenerLongClick(incidencia)
        }
    }


}




