package com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.model.db

import java.io.Serializable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Incidencia(
    @PrimaryKey(autoGenerate = true)var id:Long = 0,
    var assumpte: String,
    var descripcio: String,
    var ubicacio: String,
    var servei: String, // Jardineria, Infraestructures, Obres
    var img: Int,
    var resolt: Boolean
): Serializable
