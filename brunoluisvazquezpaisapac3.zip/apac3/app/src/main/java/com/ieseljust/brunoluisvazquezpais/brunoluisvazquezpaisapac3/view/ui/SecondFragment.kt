package com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.view.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.google.android.material.snackbar.Snackbar
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.R
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.databinding.FragmentSecondBinding
import  com .ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.model.db.Incidencia
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.viewmodel.AppIncidenciasViewModel

class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null
    private val binding get() = _binding!!

    // Adaptació a MVVM: Referència al ViewModel
    private lateinit var viewModel: AppIncidenciasViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSecondBinding.inflate(inflater, container, false)

        // La funcionalitat per inicialitzar la vista l'hem afegir el mètode onViewCreated

        // Finalment retornem l'arrel del binding

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Adaptació a MVVM: Instanciem el ViewModel, utilitzant la classe ViewModelProvider
        viewModel = ViewModelProvider(requireActivity())[AppIncidenciasViewModel::class.java]

        // Adaptació a MVVM: Afegim observadors al LiveData
        // incidenciaActual per a ser notificats dels canvis

        binding.imageViewIncidencia.setImageResource(R.drawable.incidencia)
        viewModel.incidenciaActual.observe(viewLifecycleOwner) {
            // I quan aquests es produïsquen, actualitzem les vistes de la interfície
            it?.let {
                // Actualitzem les vistes de la interfície
                // I preparem els TextViews  per actualitzar el ViewModel quan canvien de valor
                binding.imageViewIncidencia.setImageResource(it.img)

                // TextView per al assumpte
                binding.editTextAssumpteIncidencia.setText(it.assumpte)
                binding.editTextAssumpteIncidencia.doOnTextChanged { text, _, _, _ ->
                    viewModel.incidenciaActual.value?.assumpte = text.toString()
                }

                // TextView per al Descripció
                binding.editDescpIncidencia.setText(it.descripcio)
                binding.editDescpIncidencia.doOnTextChanged { text, _, _, _ ->
                    viewModel.incidenciaActual.value?.descripcio=text.toString()
                }


                // TextView per al Ubicació
                binding.editubincidencia.setText(it.ubicacio)
                binding.editubincidencia.doOnTextChanged { text, _, _, _ ->
                    viewModel.incidenciaActual.value?.ubicacio=text.toString()
                }

                // Switch pera si esta resolt
                binding.switch1.isChecked = it.resolt
                binding.switch1.setOnCheckedChangeListener { _, isChecked ->
                    viewModel.incidenciaActual.value?.resolt = isChecked
                }



                // Actualització de l'spinner
                // Recorrem els diferents valors d'aquest, i comparem
                // amb el valor guardat. Si coindiceix, deixem seleccionat el valor.

                for (i in 0 until binding.spinnerServei.adapter.count)
                    if (binding.spinnerServei.adapter.getItem(i).equals(it.resolt)) {
                        binding.spinnerServei.setSelection(i)
                        break
                    }
            }
        }

        // Observadors per saber quan s'ha guardat o modificat un contacte

        viewModel.incidenciaSaved.observe(viewLifecycleOwner) { saved ->
            saved?.let {
                // Netegem el valor per a no entrar en un bucle infinit
                viewModel.incidenciaSaved.value=null
                Snackbar.make(
                    binding.root,
                    resources.getString(R.string.IncidenciaSaved),
                    Snackbar.LENGTH_LONG
                ).setAction(resources.getString(android.R.string.ok)) {
                    findNavController().navigateUp()
                }.show()
            }
        }


        viewModel.incidenciaUpdated.observe(viewLifecycleOwner) { updated ->
            updated?.let {
                // Netegem el valor per a no entrar en un bucle infinit
                viewModel.incidenciaUpdated.value=null
                Snackbar.make(
                    binding.root,
                    resources.getString(R.string.updated),
                    Snackbar.LENGTH_LONG
                ).setAction(resources.getString(android.R.string.ok)) {
                    findNavController().navigateUp()
                }.show()
            }
        }

        // Capturem el click sobre el botó de guardar:
        binding.buttonSave.setOnClickListener {
            guardaIncidencia()
        }

    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    private fun guardaIncidencia(){

        // Creem un nou contacte a partir de la informació de les vistes
        // Recordeu que de moment agafem la imatge actual, que ara s'ubica
        // al contacte emmagatzemat al ViewModel

        // Utilitzem el constructor mitjançant arguments per nom en lloc de posicionals
        val nou= Incidencia(
            assumpte = binding.editTextAssumpteIncidencia.text.toString(),
            descripcio = binding.editDescpIncidencia.text.toString(),
            ubicacio = binding.editubincidencia.text.toString(),
            servei = binding.spinnerServei.selectedItem.toString(),
            resolt = binding.switch1.isChecked,
            img = viewModel.incidenciaActual.value?.img?:R.drawable.incidencia //La imagen sera la misma
            )

        viewModel.guardaIncidencia(nou)
    }
}