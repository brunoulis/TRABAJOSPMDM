package com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.model.db

import androidx.lifecycle.LiveData
import androidx.room.*

/* Classe d'Accés a Dades */

@Dao
interface IncidenciaDAO {

    /* Mètodes de conveniència */

    // Afegir un incidencia
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addIncidencia(incidencia: Incidencia)

    // Actualitzar un incidencia
    @Update
    suspend fun updateIncidencia(incidencia: Incidencia)

    // Eliminar un incidencia
    @Delete
    suspend fun deleteIncidencia(incidencia: Incidencia): Int

    /* Mètodes de cerca: Consultes */

    // Obtindre la llista de incidencia
    @Query("SELECT * from Incidencia")
    fun getAll(): LiveData<List<Incidencia>>


}
