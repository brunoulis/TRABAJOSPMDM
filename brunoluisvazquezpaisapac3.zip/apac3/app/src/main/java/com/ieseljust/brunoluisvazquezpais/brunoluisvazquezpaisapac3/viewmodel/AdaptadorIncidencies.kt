package com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.viewmodel

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.R
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.model.db.Incidencia


// L'adaptador rebrà en el seu constructor els objectes d'escolta
// d'esdeveniments per al clic i el clic llarg
class AdaptadorIncidencies (
    private val eventListenerClick:(Incidencia)->Unit,
    private val eventListenerLongClick: (Incidencia)->Boolean,
    private val viewModel: AppIncidenciasViewModel):RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        // S'invoca quan es crea un nou viewholder
        val inflater = LayoutInflater.from(parent.context)
        val vista = inflater.inflate(R.layout.incidencias_materialcardview_layout, parent, false)
        return IncidenciaViewHolder(vista)
    }
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        // Hem de proporcionar-li la incidencia,
        // i els esdeveniments de clic i clic llarg que rebem
        // La incidencia l'obtenim ara a través de la llista de incidencies del ViewModel
        (holder as IncidenciaViewHolder).bind(
            viewModel.incidenciaList.value?.get(position) as Incidencia,
            eventListenerClick,
            eventListenerLongClick)
    }
    // Utilitzem també la llista de incidencias del ViewModel
    override fun getItemCount(): Int {
        // Retorna el nombre d'elements del Dataset
        return viewModel.incidenciaList.value?.size ?: -1
    }
}

