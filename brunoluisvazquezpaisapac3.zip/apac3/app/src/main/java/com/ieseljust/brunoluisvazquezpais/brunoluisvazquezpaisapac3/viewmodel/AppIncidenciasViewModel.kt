package com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.model.db.Incidencia
import com.ieseljust.brunoluisvazquezpais.brunoluisvazquezpaisapac3.repository.IncidenciaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Definim el ViewModel com a AndroidViewModel, per tal de poder accedir al context
class AppIncidenciasViewModel(application: Application): AndroidViewModel(application) {

    // Definición d'atributs

    // Referència al repositori
    val repository = IncidenciaRepository.getInstance(application.applicationContext)

    // Incidencias que s'està editant actualment
    // Observeu que el Incidencieas pot ser nul

    private val _incidenciaActual=MutableLiveData<Incidencia?>() // Atribut de suport privat
    val incidenciaActual: LiveData<Incidencia?> = _incidenciaActual // Accés públic

    // Setter
    fun setIncidenciaActual(incidencia: Incidencia){
        _incidenciaActual.value=incidencia.copy()
    }

    // Setter a null
    fun cleanIncidenciaActual(){
        _incidenciaActual.value = null
    }



    // Livedata per a la llista de incidencias
    val incidenciaList: LiveData<List<Incidencia>> by lazy {
        repository!!.getIncidencias()

    }
    //val incidenciaList: LiveData<List<incidencia>>

    // Livedata per comunicar-se amb la interfície en resposta a insercions,
    // actualitzacions o esborrats de la base de dades.
    var incidenciaSaved: MutableLiveData<Boolean> = MutableLiveData()
    var incidenciaUpdated: MutableLiveData<Boolean> = MutableLiveData()
    var deletedPos: MutableLiveData<Int> = MutableLiveData()


    // Atributs LiveData per gestionar els clicks, de manera que
    // puguen ser observats per un observer en el fragment

    val incidenciaLongClicked: MutableLiveData<Incidencia> by lazy {
        MutableLiveData<Incidencia>()
    }
    val incidenciaClicked: MutableLiveData<Incidencia> by lazy {
        MutableLiveData<Incidencia>()
    }

    // Livedata per gestionar també l'element a eliminar quan
    // es fa un click llarg.
    // No ens serveix incidenciaLongClicked perquè este ha de "viure"
    // més temps.
    val incidenciaToRemove: MutableLiveData<Incidencia> by lazy {
        MutableLiveData<Incidencia>()
    }

    // LiveData per a l'adaptador, mitjançant un atribut de suport privat:
    // L'adaptador del RecyclerView també serà un LiveData per a poder ser
    // observat des de la vista.
    private val _adaptador = MutableLiveData<AdaptadorIncidencies>().apply{

        // Mitjançant value (setValue), establim el valor que contindrà el MutableLibeData
        // de tipus AdaptadorIncidencias. Aci també proporcionarem els callbacks que
        // s'han d'invocar quan es produisquen els clicks.

        value= AdaptadorIncidencies(
            { incidencia: Incidencia -> IncidenciaClickedManager(incidencia)},
            { incidencia: Incidencia -> IncidenciaLongClickedManager(incidencia)},
            this@AppIncidenciasViewModel)
    }

    // Definim la propietat per a l'adaptador, que podrem llegir des
    // de la vista (ja que _adapter és un atribut de suport privat)
    val adaptador:MutableLiveData<AdaptadorIncidencies> =_adaptador

    // Definició de mètodes

    // Definim les funcions de callback per a la gestió d'events

    // L'event el gestionarà el FirstFragment, però serà avisat pel
    // ViewModel quan es produeixen els clicks sobre cada element
    // a través d'aquestes variables de tipus MutableLiveData
    // que son incidenciaClicked i incidenciaLongClicked.

    private fun IncidenciaClickedManager(incidencia: Incidencia){
        // Para establecer el valor del liveData utilizamos value
        incidenciaClicked.value=incidencia
    }

    private fun IncidenciaLongClickedManager(incidencia: Incidencia):Boolean {
        // Per establir el valor del liveData fem ús de la propietat value
        incidenciaLongClicked.value=incidencia
        // Assignem també el LiveData incidenciaToRemove
        incidenciaToRemove.value=incidencia
        return true
    }

    fun removeIncidencia(incidencia: Incidencia) {
        viewModelScope.launch(Dispatchers.IO) {
            repository?.deleteIncidencia(incidencia)
            incidenciaList.value?.indexOf(incidencia)?.let {
                deletedPos.postValue(it)
            }
        }
    }

    // Mètode per guardar/actualitzar la incidencia
    // rebem un incidencia nou i retornarem un valor lògic que indica si
    // el incidencia s'ha guardat/actualitzat correctament.

    fun guardaIncidencia(incidencia: Incidencia){
        viewModelScope.launch(Dispatchers.IO) {
            // Comprovem si el incidencia actual existeix o és nul
            if (_incidenciaActual.value != null) { // Si existeix fem l'updte
                repository?.updateIncidencia(_incidenciaActual.value as Incidencia)
                // Activem l'indicador incidenciaUpdated per notificat a la
                // interfície que s'ha modificat un element
                incidenciaUpdated.postValue(true)
            }
            else { // Si no, l'afegim
                repository?.addIncidencia(incidencia)
                // Activem l'indicador incidenciaSaved per notificat a la
                // interfície que s'ha afegit un element
                incidenciaSaved.postValue(true)
            }

            // I tant si actualitzem com si afegim....

            // Actualitzem el incidencia actual, fent una còpia del Incidencias
            _incidenciaActual.postValue(incidencia.copy())

            // Notifiquem a l'adaptador que s'ha modificat un element
            incidenciaList.value?.indexOf(_incidenciaActual.value)
                ?.let { adaptador.value?.notifyItemChanged(it) }

        }
    }
}